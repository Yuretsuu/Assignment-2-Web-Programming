<?php 
class User{
    public $id;
    public $Fname;
    public $Lname;
    public $phone;
    public $email;
}

?>