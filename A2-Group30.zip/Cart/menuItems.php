<?php
$menu = [
    "Beef Pho" => [
        "desc" => "beef!",
        "sizes" => [
            "medium" => 12.99,
            "large" => 14.99
        ]
    ],
    "Chicken Pho" =>[
        "desc" => "chicken",
        "sizes" => [
            "medium" => 12.99,
            "large" => 14.99
        ]
    ],
    "Veggie Pho" =>  [
        "desc" => "veggie",
        "sizes" => [
            "medium" => 12.99,
            "large" => 14.99
        ]
    ]
];

function menuItemId($itemName, $itemSize) {

    return $itemName.'+'.$itemSize;
}
?>